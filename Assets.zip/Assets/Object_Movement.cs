using UnityEngine;

public class DragObject : MonoBehaviour
{
    private Camera mainCamera;
    private bool isDragging = false;
    private float distanceToCamera;

    void Start()
    {
        mainCamera = Camera.main;
    }

    void Update()
    {
        // Fareyi t�klay�nca
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform == transform)
                {
                    isDragging = true;
                    distanceToCamera = hit.distance;
                }
            }
        }

        // Fareyi s�r�klerken
        if (isDragging)
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            Vector3 worldPosition = ray.GetPoint(distanceToCamera);
            transform.position = new Vector3(worldPosition.x, transform.position.y, worldPosition.z); // Y eksenini sabit tutuyoruz
        }

        // Fareyi b�rakt���nda
        if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
        }
    }
}
