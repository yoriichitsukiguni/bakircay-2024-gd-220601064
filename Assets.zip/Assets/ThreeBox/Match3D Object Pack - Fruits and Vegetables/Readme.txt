Hello!

A set of 3D objects for creating mobile games in the Match3D genre and others.
Low poly objects are suitable for mobile platforms.

Match 3d Object Pack: Fruits & Vegetables included:

- 5 models of fruits: apple, banana, orange, strawberry, watermelon, 
- 5 models of vegetables: cabbage, carrot, cucumber, pepper, tomato,
- add. model of storage tray (can be used as a playing field),
- texture atlases for objects for better performance: ao, base color, normal map, roughness.


These objects are great for creating a game in the Match3D genre : matching 2 or 3 objects to clear the playing field.
These games have relatively simple implementation, but great benefits from development.

To demonstrate, open the demo scene: ThisAssetPack > Scenes > Asset Demo or Match 3D Demo

If you have any questions/suggestions/comments, etc., I will be happy to listen to you and try to help you.
Reviews are welcome! :) Thanks!