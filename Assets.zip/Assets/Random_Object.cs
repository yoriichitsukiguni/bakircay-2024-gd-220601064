using UnityEngine;

public class Random_Object : MonoBehaviour
{
    public GameObject[] objectPrefabs;  // Birden fazla prefab i�eren array
    public int numberOfObjects = 10;    // Ka� tane obje spawn edilece�i
    public Vector3 spawnAreaMin = new Vector3(-10, 0, -10);  // Spawn alan�n�n minimum koordinatlar�
    public Vector3 spawnAreaMax = new Vector3(10, 0, 10);   // Spawn alan�n�n maksimum koordinatlar�

    void Start()
    {
        SpawnObjects();
    }

    void SpawnObjects()
    {
        for (int i = 0; i < numberOfObjects; i++)
        {
            // Rastgele bir prefab se�
            GameObject randomObject = objectPrefabs[Random.Range(0, objectPrefabs.Length)];

            // Rastgele pozisyonu hesapla
            float x = Random.Range(spawnAreaMin.x, spawnAreaMax.x);
            float y = Random.Range(spawnAreaMin.y, spawnAreaMax.y);
            float z = Random.Range(spawnAreaMin.z, spawnAreaMax.z);
            Vector3 spawnPosition = new Vector3(x, y, z);

            // Se�ilen prefab'� olu�tur
            Instantiate(randomObject, spawnPosition, Quaternion.identity);
        }
    }
}
